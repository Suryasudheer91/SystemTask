//
//  ScreenAVC.swift
//  GnrgyInterviewTask
//
//  Created by SURYA on 23/07/21.
//

import UIKit

class ScreenAVC: UIViewController, ScreenBDelegate {

    @IBOutlet weak var itemListTable: UITableView!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var textField: UITextField!

    var timer: Timer!

    var itemList = ["Segu","Navigation","Delegate"]
    override func viewDidLoad() {
        super.viewDidLoad()

        timer = Timer.scheduledTimer(timeInterval: 60, target: self, selector: #selector(self.setRandomBackgroundColor), userInfo: nil, repeats: true)
        self.setRandomBackgroundColor()
    }

    @objc func setRandomBackgroundColor() {

    let colors = [
            UIColor(red: 255/255, green: 38/255, blue: 0/255, alpha: 1),
            UIColor(red: 0/255, green: 249/255, blue: 0/255, alpha: 1)
        ]
        let randomColor = Int(arc4random_uniform(UInt32 (colors.count)))
        self.bgView.backgroundColor = colors[randomColor]
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "showDetailSegue") {
            let VC = segue.destination as? ScreenBVC
            VC?.titleStr = textField.text!
        }
    }
    
    func addItem( _ controller: ScreenBVC?, didFinishEnteringItem item: String?) {
        
        print("Value from ScreenAVC Delegate", item)
    }
}

extension ScreenAVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ListitemsTVCell", for: indexPath) as? ListitemsTVCell {
            cell.selectionStyle = .none
            cell.titleLbl.text = itemList[indexPath.row]
            return cell
        }else{
            
            return UITableViewCell()
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ListitemsTVCell", for: indexPath) as? ListitemsTVCell {
            
        if itemList[indexPath.row] == "Segu" {
            cell.seguBtn.isUserInteractionEnabled = true
            cell.seguBtn.isHidden = false
        performSegue(withIdentifier: "showDetailSegue", sender: nil)
            
        }else if itemList[indexPath.row] == "Navigation" {
            cell.seguBtn.isUserInteractionEnabled = false
            cell.seguBtn.isHidden = true

            if let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ScreenBVC") as? ScreenBVC {
                
                if let navigator = navigationController{
                    VC.titleStr = textField.text!
                    navigator.pushViewController(VC, animated: true)
                }
            }
            
        }else{
            
            if let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ScreenBVC") as? ScreenBVC {
                cell.seguBtn.isUserInteractionEnabled = false
                cell.seguBtn.isHidden = true

                VC.delegate = self
                if let navigator = navigationController{
                   // VC.titleStr = textField.text!
                    navigator.pushViewController(VC, animated: true)
                }
            }
        }
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
