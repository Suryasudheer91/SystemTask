//
//  ScreenBVC.swift
//  GnrgyInterviewTask
//
//  Created by SURYA on 23/07/21.
//

import UIKit

protocol ScreenBDelegate: NSObjectProtocol {

    func addItem( _ controller: ScreenBVC?, didFinishEnteringItem item: String?)
    
}
class ScreenBVC: UIViewController {

    var delegate : ScreenBDelegate?
    
    @IBOutlet weak var titleLbl:UILabel!

    var titleStr = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()


        delegate?.addItem(self, didFinishEnteringItem: "Data for ScreenAVC")
        titleLbl.text = titleStr
        
    }

}
